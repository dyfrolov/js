let currentContactsArr = [];
const list = document.querySelector('#contact-list');
const form = document.querySelector('#add-contact-form');
const listLoader = document.querySelector('#list-loader');
const addLoader = document.querySelector('#add-loader');

showListLoader(false);
showAddLoader(false);

list.onclick = onRemoveContactHandler;
form.onsubmit = onAddContactHandler;

loadList();

function loadList() {
    // list.innerHTML = Store.getAll().map(mapToRow).join('');
    list.style.display = 'none';
    showListLoader(true);
    Store.getAll().then(res => {
        currentContactsArr = res;
        showListLoader(false);
        list.style.display = 'block';
        renderList();
    });
}

function renderList(){
    list.innerHTML = currentContactsArr.map(mapToRow).join('');
}

function onRemoveContactHandler(e) {
    if (e.target.tagName === 'BUTTON') {
        let index = parseInt(e.target.dataset.index);

        Store.remove(index).then(() => {
           currentContactsArr.splice(index,1);
           renderList();
        });
        
    }
}

function onAddContactHandler(e) {
    e.preventDefault();
    showAddLoader(true);
    e.target.querySelector('.btn').disabled = true;
    const contact = new Contact(
        e.target.name.value,
        e.target.lastname.value,
        e.target.phone.value,
        e.target.email.value
    );
    Store.save(contact).then(() => {
        showAddLoader(false);
        e.target.querySelector('.btn').disabled = false;
        currentContactsArr.push(contact);
        renderList();
        e.target.name.value = '';
        e.target.lastname.value = '';
        e.target.phone.value = '';
        e.target.email.value = '';
    });

}

function showListLoader(isShow){
    listLoader.style.display = isShow ? 'block' : 'none';
}

function showAddLoader(isShow){
    addLoader.style.display = isShow ? 'inline-block' : 'none';
}

function mapToRow(contact, index) {
    return `
        <li class="list-group-item d-flex w-100">
            <div class="flex-grow-1">
                <h2 class="m-0">${contact.name} ${contact.lastname}</h2>
                <h4 class="m-0">${contact.phone}</h4>
            </div>
            <button class="btn btn-danger align-self-center" data-index="${index}">
                remove
            </button>
        </li>
    `;
}