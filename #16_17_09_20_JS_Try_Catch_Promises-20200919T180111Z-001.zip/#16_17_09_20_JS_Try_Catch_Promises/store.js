const CONTACTS_KEY = 'CONTACTS';
class Store {
    static save(contact) {
        return this.getAll()
            .then(res => {
                return new Promise((resolve) => {
                    setTimeout(() => {
                        res.push(contact);
                        let str = res.map(cnt => cnt.serialization()).join('&');
                        localStorage.setItem(CONTACTS_KEY, str);
                        resolve();
                    }, 1500)
                });
            });
    }

    static remove(index) {
        return this.getAll()
        .then(res => {
            return new Promise(resolve => {
                setTimeout(()=>{
                    res.splice(index, 1);
                    if (res.length === 0) {
                        localStorage.removeItem(CONTACTS_KEY);
                    } else {
                        let str = res.map(cnt => cnt.serialization()).join('&');
                        localStorage.setItem(CONTACTS_KEY, str);
                    }
                    resolve();
                },1500);
            });
        });
    }

    static getAll() {
        return new Promise((resolve) => {
            setTimeout(() => {
                let str = localStorage.getItem(CONTACTS_KEY);
                if (!str) {
                    resolve([]);
                } else {
                    let arr = str.split('&');
                    resolve(arr.map(Contact.of));
                }
            }, 1500);
        });

    }
}