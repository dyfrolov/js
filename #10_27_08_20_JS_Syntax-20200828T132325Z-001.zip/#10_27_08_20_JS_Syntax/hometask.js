function palindrome(str) {
    let tmp = str.trim().toLowerCase();
    for(let i = 0, j = tmp.length -1; i < j; i++, j--){
        if(tmp.charAt(i) !== tmp.charAt(j)){
            return false;
        }
    }
    return true;
  }
  
  function bubbleSort(arr) {
      for(let i = 0; i < arr.length - 1; i++){
          for(let j = 0; j < arr.length - 1; j++){
              if(arr[j] > arr[j+1]){
                  let tmp = arr[j];
                  arr[j] = arr[j+1];
                  arr[j+1] = tmp;
              }
          }
      }
  }
  
  function binarySearch(arr, value) {
      let l = 0;
      let r = arr.length-1;
      while(l <= r){
          let mid = parseInt((l + r) / 2);
          if(arr[mid] === value){
              return mid;
          }else if (value > arr[mid]){
              l = mid + 1;
          }else{
              r = mid - 1;
          }
      }
    return -1;
  }
  
  let checkStr = "   Maam ";
  console.log(palindrome(checkStr));
  console.log(palindrome("asdgjk"));

  let arr = [2,3,10,1,14,-5];
  bubbleSort(arr);
  console.log(arr);

  console.log(parseInt((1+6) / 2));
  console.log(binarySearch(arr,10));
  console.log(binarySearch(arr,1));
  console.log(binarySearch(arr,100));