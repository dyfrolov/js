Implements html page using css by template Example.png

Forbidden use css-properties: display, float or position
