### Favorite Actor page

Create a simple HTML page with short info about your favorite actor like on Template.png or use content from template.

It is forbidden to use tables or any block layout techniques.

Content:

Robert Downey Jr.

Robert John Downey Jr. (born April 4, 1965) is an American actor, producer, and singer. His career has been characterized by critical and popular success in his youth, followed by a period of substance abuse and legal troubles, before a resurgence of commercial success in middle age. In 2008, Downey was named by Time magazine among the 100 most influential people in the world, and from 2013 to 2015, he was listed by Forbes as Hollywood's highest-paid actor. His films have grossed over $14.4 billion worldwide, making him the second highest-grossing box-office star of all time.

[link to wiki](https://en.wikipedia.org/wiki/Robert_Downey_Jr.)