localStorage.setItem('myKey','My Value');

let value = localStorage.getItem('myKey');
console.log(value);

// localStorage.removeItem('myKey');
localStorage.clear();

