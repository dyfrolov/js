// import Person from './calc';
import Abc from './calc';
import * as tools from './calc';
import './index.css';


console.log("Hello webpack");
console.log("Test");

// Person.sayHello("John");
Abc.sayHello("John");

console.log(tools.sum(10,20));
console.log(tools.TEST);
// console.log(diff(25,10));