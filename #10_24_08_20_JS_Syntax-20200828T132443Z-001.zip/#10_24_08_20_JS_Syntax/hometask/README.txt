Implemnts a functions:

function palindrome(str){
    return false;
}

function bubbleSort(arr){

}

function binarySearch(arr,value){
    return -1;
}